
-- Suppression si base de donnnes existante - creation
DROP DATABASE IF EXISTS wf3_php_mathilde;
CREATE DATABASE wf3_php_mathilde CHARACTER SET utf8;
USE wf3_php_mathilde;

-- Creation table advert
CREATE TABLE advert (
    id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(50) NOT NULL,
    annonce_description VARCHAR(500) NOT NULL,
    postal_code VARCHAR(5) NOT NULL,
    city VARCHAR (255) NOT NULL,
    annonce_type VARCHAR (55) NOT NULL,
    price FLOAT NOT NULL,
    reservation_message TEXT
  );

-- Insertion 3 annonces
INSERT INTO advert (title, annonce_description, postal_code,city,annonce_type, price)
VALUES ('T3 Bordeaux Centre', 'Un charmant appartement au coeur du centre de Bordeaux','33000', 'Bordeaux', 'Location', 600),
('Studio Bordeaux Centre', 'Un chaleureux studio au coeur du centre de Bordeaux', '33050', 'Bordeaux', 'Vente', 95 000)
('T1 bis Bordeaux Centre', 'Un appartement lumineux et calme au coeur du centre de Bordeaux', '33200', 'Bordeaux', 'Location', 450);
