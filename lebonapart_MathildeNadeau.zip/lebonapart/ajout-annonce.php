<?php

include_once "_head.php";
include_once "_navbar.php";

// Par defaut, alert false
$alert = false;


// Definition message d'erreur
if (isset($_GET['error'])) {
    $alert = true;
    if ($_GET['error'] == "missingInput") {
        $type = "secondary";
        $message = "Les champs requis sont vides";
    }
    if ($_GET['error'] == "unknownError") {
        $type = "warning";
        $message = "Une erreur s'est produite, réessayer ultérieurement.";
    }}

?>


<!-- Formulaire d'ajout d'une annonce-->
<main class="mx-5 px-5 my-5">
    <!-- affichage message erreur -->
<?php echo $alert ? "<div class='alert alert-{$type} mt-2'>{$message}</div>" : ''; ?>
    <form action="ajout-annonce_post.php" method="post" enctype="multipart/form-data">

        <div class="mb-3">
            <label for="title" class="form-label">Titre de l'annonce</label>
            <input type="text" class="form-control" id="title" placeholder="appartement T2 Bordeaux centre avec terrasse" name="title"
                required>
        </div>

        <div class="mb-3">
            <label for="annonce_description" class="form-label">Description de l'annonce</label>
            <textarea class="form-control" id="annonce_description" rows="3" name="annonce_description"
                required></textarea>
        </div>

        <div class="mb-3">
            <label for="postal_code" class="form-label">Code postal</label>
            <input class="form-control" type="text" id="postal_code" name="postal_code"  placeholder="33000" required>
        </div>

         <div class="mb-3">
            <label for="city" class="form-label">Ville</label>
            <input type="text" class="form-control" id="city"
                placeholder="Bordeaux" name="city" required>
        </div>     

        <div class="mb-3">
            <label for="annonce_type" class="form-label">Type d'annonce</label>
            <input type="text" class="form-control" id="annonce_type" placeholder="Location/Vente" name="annonce_type"
                required>
        </div>

        <div class="mb-3">
            <label for="price" class="form-label">Prix</label>
            <input type="number" class="form-control" id="price"
                placeholder="450/ mois" name="price" required>
        </div>


        
        <div class="mb-3">
            <button type="submit" class="btn btn-outline-success btn-lg">Ajouter une annonce</button>
        </div>

    </form>
</main>