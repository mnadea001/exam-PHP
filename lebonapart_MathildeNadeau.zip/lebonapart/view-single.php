<?php

require 'includes/connect.php';
include_once "_head.php";
include_once "_navbar.php";

include_once '_view-single.php';

?>

<main class="main-content position-relative max-height-vh-100 h-100 mt-1 border-radius-lg ps ps--active-y">
    <div class="card container m-4 p-4">
        <h3><?php echo $line['title']; ?> </h3>
        <p class="text-bold"><strong>Description :</strong> </p>
        <p><?php echo $line['annonce_description']; ?></p>
        <hr>
        <p class="btn btn-success col-2"><strong>Prix:</strong></p>
        <p><?php echo $line['price']; ?>€</p>
        <hr>
        <p class="text-bold"><strong>Ville:</strong> </p>
        <p><?php echo $line['city']; ?></p>
        <hr>
        <hr>
        <p class="text-bold"><strong>type d'annonce:</strong> </p>
        <p><?php echo $line['annonce_type']; ?></p>
        <hr>
<!-- Si reservation_message est vide, affichage textarea et bouton reservation, sinon affichage du message et bouton réservé -->
        <?php
if(!empty($line['reservation_message'])){  ?>
        <p class="text-bold"><strong>Message de réservation:</strong> </p>
        <p><?php echo $line['reservation_message']; ?></p>
        <button class="btn-danger ">Réservé</button>
        <?php
} else {?>
         <form action="_booking_post.php" method="post" enctype="multipart/form-data">
            <label for="reservation_message" class="form-label">Message de reservation</label>
            <textarea class="form-control" id="reservation_message" rows="3" name="reservation_message"
               ></textarea>
  <input type="hidden" name="id" value="<?php echo $line['id']; ?>">

               <hr>

<button type="submit" class="btn btn-info col-2"><strong>Réserver</strong> </button>
</form> 
<?php } ?>
    
        <a href="index.php">Retour aux annonces</a>
    </div>
 
</main>

<?php

include_once "_footer.php";
?>