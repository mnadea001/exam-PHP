<?php

$id = htmlspecialchars(trim($_GET['id']));

        $sql = 'SELECT * FROM advert WHERE id=:id';
        $reqLine = $connexion->prepare($sql);
        $reqLine->bindValue(':id', $id);
        $reqLine->execute();
        $line = $reqLine->fetch();


        ?>