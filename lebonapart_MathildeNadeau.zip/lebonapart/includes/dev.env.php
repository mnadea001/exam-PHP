<?php

define("DBHOST",'localhost');
define("DBNAME",'wf3_php_mathilde');
define("USER","root");
define("PASS","");


?>