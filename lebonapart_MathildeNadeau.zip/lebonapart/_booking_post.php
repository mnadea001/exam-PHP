<?php

require 'includes/connect.php';
include_once '_view-single.php';


    echo '<pre>';
    print_r($_POST);
    echo '</pre>';



    $reservation_message = htmlspecialchars(trim($_POST['reservation_message']));
    $id = intval($_POST['id']);


    try {
        $sqlEdit = 'UPDATE advert SET reservation_message=:reservation_message  WHERE id=:id';

        $reqEdit = $connexion->prepare($sqlEdit);
        $reqEdit->bindValue(':reservation_message', $reservation_message, PDO::PARAM_STR);
        $reqEdit->bindValue(':id', $id, PDO::PARAM_INT);
        $reqEdit->execute();
        header("Location:index.php?success=bookingdone");
    } catch (PDOException $e) {
        echo $e->getMessage();
    }