<!-- Requete SQL pour afficher toutes les annonces -->
<!-- Ajout de la contrainte ORDER BY ... DESC sur le champ ID pour que les annonces les plus recentes s'affichent en premier.
Puisque nos annonces ne comportent pas de champs date, l'ID remplace ce champs puisque les ID sont croissantes : les + petits sont les + anciens, il faut donc les afficher de facon decroissante pour avoir les annonces plus recentes en premier.  -->
<!-- En rajoutant LIMIT 15, seul les 15 annonces les plus recentes seront affichees. -->

<?php


$annonces = $connexion->query('SELECT * FROM advert ORDER BY id DESC LIMIT 15')->fetchAll();
?>