<?php

require 'includes/connect.php';



echo '<pre>';
var_dump($_POST);
echo '</pre>';

//? Vérification de la validité du formulaire
if(empty($_POST['title']) || empty($_POST['annonce_description'])  || empty($_POST['postal_code']) || empty($_POST['city'])|| empty($_POST['annonce_type']) || empty($_POST['price'])){
    header('Location:ajout-annonce.php?error=missingInput');
    exit();
} else {
    //? Si valide, initialisation des variables avec assainissement via trim et htmlspecialchars. On utilise floatval sur le prix, pour s'assurer d'avoir un prix décimal.
    $title = htmlspecialchars(trim($_POST['title']));
    $annonce_description = htmlspecialchars(trim($_POST['annonce_description']));
    $postal_code = htmlspecialchars(trim($_POST['postal_code']));
    $city = htmlspecialchars(trim($_POST['city']));
    $annonce_type = htmlspecialchars(trim($_POST['annonce_type']));
    $price = htmlspecialchars(floatval($_POST['price']));}


// Requete d'insertion dans la base SQL 
try{
$insertAnnonce = 'INSERT INTO advert (title,annonce_description,postal_code,city, annonce_type, price) VALUES(:title,:annonce_description,:postal_code,:city,:annonce_type,:price)';
$reqInsertAnnonce = $connexion->prepare($insertAnnonce);
$reqInsertAnnonce->bindValue(':title',$title,PDO::PARAM_STR);
$reqInsertAnnonce->bindValue(':annonce_description',$annonce_description,PDO::PARAM_STR);
$reqInsertAnnonce->bindValue(':postal_code',$postal_code,PDO::PARAM_STR);
$reqInsertAnnonce->bindValue(':city',$city,PDO::PARAM_STR);
$reqInsertAnnonce->bindValue(':annonce_type',$annonce_type,PDO::PARAM_STR);
$reqInsertAnnonce->bindValue(':price',$price);
$reqInsertAnnonce->execute();
header('Location:index.php?success=addedAnnonce');
} catch (PDOException $e) {
    echo $e->getMessage();
}
    ?>