<!-- Requete SQL pour afficher toutes les annonces -->

<?php


$annonces = $connexion->query('SELECT * FROM advert')->fetchAll();
?>