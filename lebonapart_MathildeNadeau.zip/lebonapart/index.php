<?php
// require 'includes/config.php';
require 'includes/connect.php';
include '_view-annonces.php';
include_once '_head.php';

$alert = false;

// Affichage message si ajout de produit valide / si reservation effectuee 
if (isset($_GET['success'])) {
    $alert = true;
    $type= "success";

    if($_GET['success'] == "addedAnnonce"){
        $alert = true;
        $type = "success";
        $message = "Votre annonce a bien été ajouté";
    }
    
    if($_GET['success'] == "bookingdone")
    {
        $alert = true;
        $type = "success";
        $message = "Votre réservation a été effectué";
    }}
?>

<body>

<!-- Insertion navbar -->
<?php
include_once '_navbar.php';

?>
<main class="main-content position-relative max-height-vh-100 h-100 mt-1 border-radius-lg ps ">
<div class="center">
    <img src="assets\yolk-coworking-krakow-i2V0hW6pCJM-unsplash.jpg" alt="logement"class="ml-5 max-height-vh-20 w-50 img-fluid">
</div>

<!-- Si alerte true affiche message sinon n'affiche rien -->

<?php echo $alert ? "<div class='alert alert-$type mt-2'>$message</div>" : ""; ?>
<!-- Tableau affichant annonces -->
    <div class="row">
            <div class="col-12">
                <div class="card mb-4">
                    <div class="card-header pb-0">
                        <h6>Nos appartements disponibles</h6>
                    </div>
                    <div class="card-body px-0 pt-0 pb-2">
                        <div class="table-responsive p-0">
                            <table class="table align-items-center mb-0">
                                <thead>
                                    <tr>
                                    <th class="text-uppercase text-secondary text-center text-xxs font-weight-bolder opacity-7">
                                            ID#</th>
                                    <th class="text-uppercase text-secondary text-center text-xxs font-weight-bolder opacity-7">
                                            Nom</th>
                                    <th class="text-uppercase text-secondary text-center text-xxs font-weight-bolder opacity-7 ps-2">
                                            Prix</th>
                                    <th class="text-center text-uppercase text-center text-secondary text-xxs font-weight-bolder opacity-7">
                                            Ville</th>
                                    <th class="text-center text-uppercase text-center text-secondary text-xxs font-weight-bolder opacity-7">
                                            Type d'annonce</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        foreach($annonces as $advert){
                                    ?>
                                    <tr>
                                        <td>
                                            <p class="text-xs font-weight-bold mb-0 text-center">
                                                <?= $advert['id'] ?></p>
                                        </td>
                                        <td>

                                            <div class="d-flex px-2 py-1">
                                                <div class="d-flex flex-column justify-content-center">
                                                    <!-- Style text-transform uppercase afin que les titres apparaissent en majuscules -->
                                                    <h6 class="mb-0 text-sm text-center" style = "text-transform:uppercase;"><?= $advert['title'] ?></h6>
                                                </div>
                                            </div>
                                        </td>

                                        <td>
                                            <p class="text-xs text-center font-weight-bold mb-0"><?= $advert['price'] ?>€</p>
                                        </td>

                                        <td>
                                            <p class="text-xs text-center font-weight-bold mb-0"><?= $advert['city']; ?></p>
                                        </td>
                                        <td>
                                            <p class="text-xs text-center font-weight-bold mb-0"><?= $advert['annonce_type']; ?></p>
                                        </td>
  
                                    </tr>
                                    <?php
                                        }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>


    </div>
   <a href="view-all.php">Consulter toutes les annonces</a>
</main>

 </body>

 <?php 
include_once "_footer.php";
?>